<?php
session_start();

// Validación si no hay sesión activa
// if (!isset($_SESSION['usuario'])) {
//     header("Location: ../LogIn/index.php");
//     exit();
// }

// Validación de perfil: 1 = Usuario común, 0 = Admin
if ($_SESSION['TipoUsuario'] == 1) {
    include("../Header/Header.php");
    echo "
    <!DOCTYPE html>
<html lang='es>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Mantenimiento de Usuarios - Alpha Academy</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }
        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-modificar {
            background-color: #28a745;
            color: white;
        }
        .btn-modificar:hover {
            background-color: #218838;
        }
        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
        }
        footer a {
            color: #3498db;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class='container mt-4'>
    <h2 class='mb-4'>Mantenimiento de Usuarios</h2>";
    echo "<h2 style='color:red; text-align:center; margin-top:50px;'>Su perfil no tiene acceso a esta sección.</h2>";
    exit();
}

include("../Header/Header.php");
include("../DB/DBConect.php");

// Establecer la conexión con la base de datos
$conexion = DBConectar();

// Realizar la consulta
$query = "SELECT * FROM Usuarios";
$resultado = $conexion->query($query);

// Verificar si hay errores en la consulta
if (!$resultado) {
    die("Error en la consulta: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mantenimiento de Usuarios - Alpha Academy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }
        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-modificar {
            background-color: #28a745;
            color: white;
        }
        .btn-modificar:hover {
            background-color: #218838;
        }
        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
        }
        footer a {
            color: #3498db;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-4">Mantenimiento de Usuarios</h2>
    <table class="table table-bordered table-hover bg-white">
        <thead class="table-primary">
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Cédula</th>
                <th>Teléfono</th>
                <th>Usuario</th>
                <th>Contraseña (Encriptada)</th>
                <th>Tipo de Usuario</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($resultado->num_rows > 0) {
                while ($u = $resultado->fetch_assoc()) {
                    $tipoUsuario = $u["TipoUsuario"] == 1 ? "Admin" : "Sencillo";
                    echo "<tr>
                            <td>" . htmlspecialchars($u["NombreUsuario"]) . "</td>
                            <td>" . htmlspecialchars($u["CorreoUsuario"]) . "</td>
                            <td>" . htmlspecialchars($u["Identificacion"]) . "</td>
                            <td>" . htmlspecialchars($u["Telefono"]) . "</td>
                            <td>" . htmlspecialchars($u["idUsuario"]) . "</td>
                            <td>" . htmlspecialchars($u["ContraseñaUsuario"]) . "</td>
                            <td>" . htmlspecialchars($tipoUsuario) . "</td>
                            <td>
                                <a href='modificar_usuario.php?id=" . $u["idUsuario"] . "' class='btn btn-sm btn-modificar'>Modificar</a>
                            </td>
                        </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No se encontraron usuarios.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<footer>
    <p>&copy; 2025 Alpha Academy. Todos los derechos reservados.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conexion->close();
?>