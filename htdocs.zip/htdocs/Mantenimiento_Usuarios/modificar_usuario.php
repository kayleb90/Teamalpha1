<?php
include("../Header/Header.php");
include("../DB/DBConect.php");

$conexion = DBConectar();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM Usuarios WHERE idUsuario = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    if ($resultado->num_rows == 1) {
        $usuario = $resultado->fetch_assoc();
    } else {
        echo "Usuario no encontrado.";
        exit;
    }
} elseif (isset($_POST['guardar'])) {
    $id = $_POST['idUsuario'];
    $nombre = $_POST['NombreUsuario'];
    $correo = $_POST['CorreoUsuario'];
    $identificacion = $_POST['Identificacion'];
    $telefono = $_POST['Telefono'];
    $contrasena = $_POST['ContraseñaUsuario'];
    $tipo = $_POST['TipoUsuario'];

    $query = "UPDATE Usuarios SET NombreUsuario=?, CorreoUsuario=?, Identificacion=?, Telefono=?, ContraseñaUsuario=?, TipoUsuario=? WHERE idUsuario=?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("sssssis", $nombre, $correo, $identificacion, $telefono, $contrasena, $tipo, $id);
    
    if ($stmt->execute()) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error al actualizar el usuario: " . $conexion->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Usuario - Alpha Academy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }

        header {
            background-color: #3498db;
            color: white;
            text-align: center;
            padding: 20px;
        }

        header h1 {
            margin: 0;
        }

        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }

        .btn-modificar {
            background-color: #28a745;
            color: white;
        }

        .btn-modificar:hover {
            background-color: #218838;
        }

        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: 40px;
        }

        footer a {
            color: #3498db;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-4">Modificar Usuario</h2>
    <form method="POST" action="modificar_usuario.php">
        <input type="hidden" name="idUsuario" value="<?= htmlspecialchars($usuario['idUsuario']) ?>">
        
        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="NombreUsuario" class="form-control" value="<?= htmlspecialchars($usuario['NombreUsuario']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Correo</label>
            <input type="email" name="CorreoUsuario" class="form-control" value="<?= htmlspecialchars($usuario['CorreoUsuario']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Cédula</label>
            <input type="text" name="Identificacion" class="form-control" value="<?= htmlspecialchars($usuario['Identificacion']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Teléfono</label>
            <input type="text" name="Telefono" class="form-control" value="<?= htmlspecialchars($usuario['Telefono']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Contraseña</label>
            <input type="text" name="ContraseñaUsuario" class="form-control" value="<?= htmlspecialchars($usuario['ContraseñaUsuario']) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Tipo de Usuario</label>
            <select name="TipoUsuario" class="form-select">
                <option value="1" <?= $usuario['TipoUsuario'] == 1 ? 'selected' : '' ?>>Admin</option>
                <option value="0" <?= $usuario['TipoUsuario'] == 0 ? 'selected' : '' ?>>Sencillo</option>
            </select>
        </div>

        <button type="submit" name="guardar" class="btn btn-primary">Guardar Cambios</button>
        <a href="index.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<footer class="footer-dark">
    <p>&copy; 2025 Alpha Academy. Todos los derechos reservados.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conexion->close();
?>