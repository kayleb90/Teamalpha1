<?php
session_start();
include('/xampp/htdocs/DB/DBConect.php'); 

$errors = [];
$cedula = $email = $username = $password = $phone = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cedula = trim($_POST['cedula']);
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($cedula)) {
        $errors['cedula'] = 'El número de cédula es requerido';
    }

    if (empty($email)) {
        $errors['email'] = 'El correo electrónico es requerido';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Por favor ingresa un correo electrónico válido';
    }

    if (empty($username)) {
        $errors['username'] = 'El nombre de usuario es requerido';
    } elseif (strlen($username) < 4) {
        $errors['username'] = 'El nombre debe tener al menos 4 caracteres';
    }

    if (empty($phone)) {
        $errors['phone'] = 'El número de teléfono es requerido';
    }

    if (empty($password)) {
        $errors['password'] = 'La contraseña es requerida';
    } elseif (strlen($password) < 6) {
        $errors['password'] = 'La contraseña debe tener al menos 6 caracteres';
    }

    if ($password !== $confirm_password) {
        $errors['confirm_password'] = 'Las contraseñas no coinciden';
    }

    if (empty($errors)) {
        try {
            $conexion = DBConectar();
            $stmt = $conexion->prepare("CALL SP_InsertarUsuario(?, ?, ?, ?, ?)");

            $hashedPassword = hash('sha256', $password);

            $stmt->bind_param("sssss", $cedula, $email, $username, $phone, $hashedPassword);

            if ($stmt->execute()) {
                $_SESSION['message'] = '¡Registro exitoso! Bienvenido/a ' . htmlspecialchars($username);
                header('Location: /Index.php');
                exit;
            } else {
                $errors['general'] = 'Error al registrar el usuario. Intenta nuevamente.';
            }

            $stmt->close();
            $conexion->close();
        } catch (Exception $e) {
            $errors['general'] = 'Error: ' . $e->getMessage();
        }
    }
}
?>



<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Cursos en Línea</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 100%;
            max-width: 400px;
        }
        
        h1 {
            color: #3498db;
            text-align: center;
            margin-bottom: 24px;
        }

        h2 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 24px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 6px;
            color: #2c3e50;
            font-weight: bold;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        input:focus {
            border-color: #3498db;
            outline: none;
        }
        
        .error {
            color: #e74c3c;
            font-size: 14px;
            margin-top: 5px;
        }
        
        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s;
        }
        
        button:hover {
            background-color: #2980b9;
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            color: #7f8c8d;
        }
        
        .login-link a {
            color: #3498db;
            text-decoration: none;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="brand">Alpha Academy</h1>
        <h2 class="brand">Regístrate</h2>
        
        <?php 
        if (!empty($errors)): ?>
            <div style="color: #e74c3c; margin-bottom: 15px;">
                Por favor corrige los siguientes errores:
            </div>
        <?php endif; ?>
        <?php if (!empty($errors)): ?>
    <div style="color: #e74c3c; margin-bottom: 15px;">
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

        
        <form action="Index.php" method="POST">
            <div class="form-group">
                <label for="cedula">Número de Cédula</label>
                <input type="text" id="cedula" name="cedula" value="<?php echo htmlspecialchars($cedula); ?>" required>
                <?php if (isset($errors['cedula'])): ?>
                    <div class="error"><?php echo $errors['cedula']; ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="email">Correo Electrónico</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                <?php if (isset($errors['email'])): ?>
                    <div class="error"><?php echo $errors['email']; ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="username">Nombre de Usuario</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                <?php if (isset($errors['username'])): ?>
                    <div class="error"><?php echo $errors['username']; ?></div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="phone">Numero de telefono</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required>
                <?php if (isset($errors['phone'])): ?>
                    <div class="error"><?php echo $errors['phone']; ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required>
                <?php if (isset($errors['password'])): ?>
                    <div class="error"><?php echo $errors['password']; ?></div>
                <?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Repetir Contraseña</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
                <?php if (isset($errors['confirm_password'])): ?>
                    <div class="error"><?php echo $errors['confirm_password']; ?></div>
                <?php endif; ?>
            </div>
             
            <button type="submit">Registrarse</button>
        </form>
        
        <div class="login-link">
            ¿Ya tienes una cuenta? <a href="../login">Inicia sesión</a>
        </div>
    </div>
</body>
</html>
