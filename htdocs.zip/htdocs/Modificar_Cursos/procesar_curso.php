<?php
include("../DB/DBConect.php"); // Asegúrate de tener bien la ruta

$conexion = DBConectar();

// Obtener datos del formulario
$course_id = $_POST['course_id'] ?? null;
$nombreCurso = $_POST['nombreCurso'];
$fechaInicio = $_POST['fechaInicio'];
$duracion = $_POST['duracion'];
$capacidad = $_POST['capacidad'];
$disponibilidad = $_POST['disponibilidad'];
$instructor = $_POST['instructor'];

// Si hay un course_id, es una actualización
if ($course_id) {
    $query = "UPDATE Cursos SET 
                NombreCurso = ?, 
                FechaInicioCurso = ?, 
                DuracionCurso = ?, 
                CapacidadCurso = ?, 
                Disponibilidad = ?, 
                idUsuario = ? 
              WHERE idCurso = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("ssiiiii", $nombreCurso, $fechaInicio, $duracion, $capacidad, $disponibilidad, $instructor, $course_id);
} else {
    // Si no hay course_id, es una inserción
    $query = "INSERT INTO Cursos (NombreCurso, FechaInicioCurso, DuracionCurso, CapacidadCurso, Disponibilidad, idUsuario)
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("ssiiis", $nombreCurso, $fechaInicio, $duracion, $capacidad, $disponibilidad, $instructor);
}

if ($stmt->execute()) {
    header("Location: /Mantenimiento_Cursos/index.php");
    exit;
} else {
    echo "Error: " . $stmt->error;
}

$conexion->close();
?>