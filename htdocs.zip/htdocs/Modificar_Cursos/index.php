<?php
include("../Header/Header.php");
include("../DB/DBConect.php"); // Asegúrate de tener bien la ruta

// Conexión a la base de datos
$conexion = DBConectar();

// Si hay un ID de curso en la URL, lo usamos para modificar el curso
if (isset($_GET['course_id'])) {
    $course_id = $_GET['course_id'];
    $query = "SELECT * FROM Cursos WHERE idCurso = '$course_id'";
    $resultado = $conexion->query($query);

    if (!$resultado) {
        die("Error en la consulta: " . $conexion->error);
    }

    // Obtener los datos del curso a modificar
    $curso = $resultado->fetch_assoc();
} else {
    // Si no hay ID, es para crear un nuevo curso
    $curso = [
        'idCurso' => '',
        'NombreCurso' => '',
        'FechaInicioCurso' => '',
        'DuracionCurso' => '',
        'CapacidadCurso' => '',
        'Disponibilidad' => '',
        'idUsuario' => '' // Suponiendo que este campo es obligatorio
    ];
}

// Obtener usuarios para el instructor
$instructores = $conexion->query("SELECT idUsuario, NombreUsuario FROM Usuarios");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar o Agregar Curso - Alpha Academy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }

        header {
            background-color: #3498db;
            color: white;
            text-align: center;
            padding: 20px;
        }

        header h1 {
            margin: 0;
        }

        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .btn-modificar {
            background-color: #28a745;
            color: white;
        }

        .btn-modificar:hover {
            background-color: #218838;
        }

        .btn-cerrar {
            background-color: #dc3545;
            color: white;
        }

        .btn-cerrar:hover {
            background-color: #c82333;
        }

        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
        }

        footer a {
            color: #3498db;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-4"><?= $curso['idCurso'] ? 'Modificar Curso' : 'Agregar Nuevo Curso' ?></h2>
    <form action="procesar_curso.php" method="POST">
        <input type="hidden" name="course_id" value="<?= $curso['idCurso'] ?>">

        <div class="mb-3">
            <label for="nombreCurso" class="form-label">Nombre del Curso</label>
            <input type="text" class="form-control" id="nombreCurso" name="nombreCurso" value="<?= htmlspecialchars($curso['NombreCurso']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="fechaInicio" class="form-label">Fecha de Inicio</label>
            <input type="date" class="form-control" id="fechaInicio" name="fechaInicio" value="<?= $curso['FechaInicioCurso'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="duracion" class="form-label">Duración (horas)</label>
            <input type="number" class="form-control" id="duracion" name="duracion" value="<?= $curso['DuracionCurso'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="capacidad" class="form-label">Capacidad</label>
            <input type="number" class="form-control" id="capacidad" name="capacidad" value="<?= $curso['CapacidadCurso'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="disponibilidad" class="form-label">Cupos Disponibles</label>
            <input type="number" class="form-control" id="disponibilidad" name="disponibilidad" value="<?= $curso['Disponibilidad'] ?>" required>
        </div>

        <div class="mb-3">
            <label for="instructor" class="form-label">Instructor</label>
            <select class="form-select" id="instructor" name="instructor" required>
                <?php while ($instructor = $instructores->fetch_assoc()) { ?>
                    <option value="<?= $instructor['idUsuario'] ?>" <?= $curso['idUsuario'] == $instructor['idUsuario'] ? 'selected' : '' ?>>
                        <?= $instructor['NombreUsuario'] ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary"><?= $curso['idCurso'] ? 'Actualizar Curso' : 'Agregar Curso' ?></button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conexion->close();
?>