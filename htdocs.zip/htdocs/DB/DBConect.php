<?php
function DBConectar() {
    $host = 'mysql-2fc47aa4-abrahansalascarvajal-91df.i.aivencloud.com:21130';
    $usuario = 'avnadmin'; 
    $clave = 'AVNS_5_Qq1ireBL5n9VFog2M'; 
    $baseDeDatos = 'AlphaTeam'; 

    $conexion = new mysqli($host, $usuario, $clave, $baseDeDatos);

    if ($conexion->connect_error) {
        die('Error en la conexión: ' . $conexion->connect_error);
    }//else{echo'exito';}

    return $conexion;
}
?>
<?php
DBConectar();
?>
