<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['idUsuario'])) {
    header("Location: ../LogIn/index.php");
    exit;
}

$nombre = $_SESSION['NombreUsuario'];
$correo = $_SESSION['CorreoUsuario'];

include("../DB/DBConect.php");
$conexion = DBConectar();

$idUsuario = $_SESSION['idUsuario'];
$sql = "SELECT c.NombreCurso, c.FechaInicioCurso, c.DuracionCurso, c.Precio
        FROM MatriculaCursos m
        INNER JOIN Cursos c ON m.idCurso = c.idCurso
        WHERE m.idUsuario = '$idUsuario'";

$resultado = mysqli_query($conexion, $sql);

$cursos = [];
if ($resultado) {
    while ($fila = mysqli_fetch_assoc($resultado)) {
        $cursos[] = $fila;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Alpha Academy - Mi Cuenta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }

        header {
            background-color: #3498db;
            color: white;
            text-align: center;
            padding: 20px;
        }

        header h1 {
            margin: 0;
        }

        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }

        .table th, .table td {
            vertical-align: middle;
        }

        .btn-modificar {
            background-color: #28a745;
            color: white;
        }

        .btn-modificar:hover {
            background-color: #218838;
        }

        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
        }

        footer a {
            color: #3498db;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<?php include "../Header/Header.php"; ?>

<div class="container mt-5">
    <div class="card p-4">
        <h2>Información Personal</h2>
        <p><strong>Nombre:</strong> <?= htmlspecialchars($nombre) ?></p>
        <p><strong>Correo:</strong> <?= htmlspecialchars($correo) ?></p>

        <?php if (count($cursos) > 0): ?>
            <h4 class="mt-4">Cursos Matriculados</h4>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Fecha de Inicio</th>
                        <th>Duración</th>
                        <th>Precio</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cursos as $curso): ?>
                        <tr>
                            <td><?= htmlspecialchars($curso['NombreCurso']) ?></td>
                            <td><?= htmlspecialchars($curso['FechaInicioCurso']) ?></td>
                            <td><?= htmlspecialchars($curso['DuracionCurso']) ?> semanas</td>
                            <td>₡<?= number_format($curso['Precio'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <h4 class="mt-4">Cursos Matriculados</h4>
            <p><em>No tiene cursos matriculados actualmente.</em></p>
        <?php endif; ?>

        <a href="../LogIn/logout.php" class="btn btn-danger mt-3">Cerrar Sesión</a>
    </div>
</div>

<footer class="text-center mt-5">
    <p>&copy; 2025 Alpha Academy. Todos los derechos reservados.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>