<?php
session_start();
include "../DB/DBConect.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $idCurso = $_POST['course'];
    $idUsuario = $_SESSION['idUsuario'];

    // Verificar que el usuario esté logueado
    if (!$idUsuario) {
        die("Error: No has iniciado sesión.");
    }

    // Conectar a la base de datos
    $conexion = DBConectar();

    // Preparar la consulta para evitar SQL Injection
    $stmt = $conexion->prepare("INSERT INTO MatriculaCursos (idUsuario, idCurso) VALUES (?, ?)");
    $stmt->bind_param("ii", $idUsuario, $idCurso);

    if ($stmt->execute()) {
        echo "<script>alert('¡Matrícula exitosa!'); window.location.href = '../Index.php';</script>";
    } else {
        echo "Error al matricular: " . $stmt->error;
    }

    $stmt->close();
    $conexion->close();
} else {
    echo "Acceso no permitido.";
}
?>