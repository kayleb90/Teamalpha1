<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alpha Academy - Cursos en Línea</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }

        header {
            background-color: #3498db;
            color: white;
            text-align: center;
            padding: 20px;
        }

        header h1 {
            margin: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }

        .section-title {
            font-size: 24px;
            color: #3498db;
            margin-bottom: 15px;
        }

        .cta-button {
            background-color: #3498db;
            color: white;
            padding: 12px 25px;
            font-size: 18px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .cta-button:hover {
            background-color: #2980b9;
        }

        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
        }

        footer a {
            color: #3498db;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<?php
    session_start();
    include "../Header/Header.php";
    include "../DB/DBConect.php";

    $conexion = DBConectar();

    // ID del usuario logueado (si está)
    $idUsuario = $_SESSION['idUsuario'] ?? null;

    // Consulta para obtener los cursos de la BD
    $query = "SELECT idCurso, NombreCurso, FechaInicioCurso FROM Cursos";
    $resultadoCursos = $conexion->query($query);
?>

<div class="container">
    <h2 class="section-title">Matricúlate en nuestros cursos</h2>
    <p>¡Da el primer paso hacia tu aprendizaje y desarrollo profesional! Completa el siguiente formulario para matricularte en uno de nuestros cursos en línea.</p>

    <form id="formMatricula" action="matricular.php" method="POST" onsubmit="return confirmarMatricula();">
        <!-- Curso elegido -->
        <div class="mb-3">
            <label for="course" class="form-label">Selecciona el curso</label>
            <select class="form-select" id="course" name="course" required onchange="actualizarFechaInicio()">
                <option value="" disabled selected>Selecciona un curso</option>
                <?php
                    if ($resultadoCursos && $resultadoCursos->num_rows > 0) {
                        while ($curso = $resultadoCursos->fetch_assoc()) {
                            $idCurso = htmlspecialchars($curso['idCurso']);
                            $nombreCurso = htmlspecialchars($curso['NombreCurso']);
                            $fechaInicio = htmlspecialchars($curso['FechaInicioCurso']);
                            echo "<option value='$idCurso' data-fecha='$fechaInicio'>$nombreCurso</option>";
                        }
                    } else {
                        echo "<option disabled>No hay cursos disponibles</option>";
                    }
                ?>
            </select>
        </div>

        <!-- Fecha de inicio -->
        <div class="mb-3">
            <label for="startDate" class="form-label">Fecha de inicio del curso</label>
            <input type="date" class="form-control" id="startDate" name="startDate" readonly>
        </div>

        <!-- Comentarios adicionales -->
        <div class="mb-3">
            <label for="comments" class="form-label">Comentarios adicionales</label>
            <textarea class="form-control" id="comments" name="comments" rows="4"></textarea>
        </div>

        <!-- Botón de enviar -->
        <button type="submit" class="btn btn-primary">Matricúlate</button>
    </form>
</div>

<footer>
    <p>&copy; 2025 Alpha Academy. Todos los derechos reservados.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    const idUsuario = <?= json_encode($idUsuario) ?>;

    function actualizarFechaInicio() {
        const select = document.getElementById('course');
        const fechaInput = document.getElementById('startDate');
        const opcionSeleccionada = select.options[select.selectedIndex];
        const fecha = opcionSeleccionada.getAttribute('data-fecha');
        fechaInput.value = fecha;
    }

    function confirmarMatricula() {
        if (!idUsuario) {
            alert("Debes iniciar sesión para poder matricularte.");
            window.location.href = "../LogIn/index.php";
            return false;
        }

        const cursoSeleccionado = document.getElementById('course');
        const nombreCurso = cursoSeleccionado.options[cursoSeleccionado.selectedIndex].text;

        return confirm(`¿Estás seguro de que deseas matricularte en el curso "${nombreCurso}"?`);
    }
</script>

<?php $conexion->close(); ?>

</body>
</html>