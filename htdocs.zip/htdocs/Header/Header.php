<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
<header class="navbar-dark bg-dark py-3">
    <div class="container">
        <h1 class="text-white">Alpha Academy - Cursos en Línea</h1>
    </div>
</header>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Alpha Academy</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <?php if (isset($_SESSION['idUsuario'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php">INICIO</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/Matricula_de_cursos">Matrícula de cursos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../Mi_Cuenta/index.php">Mi Cuenta</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../Mantenimiento_Usuarios/index.php">Mantenimiento de Usuarios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../Mantenimiento_Cursos/index.php">Mantenimiento de Cursos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../LogIn/logout.php">Cerrar Sesión</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="../LogIn/index.php">Iniciar Sesión</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
