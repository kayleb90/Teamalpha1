<?php
include("../DB/DBConect.php"); // Ajusta la ruta si es necesario

// Validar si se recibió el ID por GET
if (isset($_GET['id'])) {
    $idCurso = $_GET['id'];

    // Conectar a la base de datos
    $conexion = DBConectar();

    // Preparar y ejecutar el UPDATE
    $query = "UPDATE Cursos SET Disponibilidad = 0 WHERE idCurso = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("i", $idCurso);

    if ($stmt->execute()) {
        // Opcionalmente, podrías actualizar también el campo Disponibilidad
        // $conexion->query("UPDATE Cursos SET Disponibilidad = 'Cerrado' WHERE idCurso = $idCurso");

        header("Location: index.php"); // Redirigir de nuevo a la lista
        exit;
    } else {
        echo "Error al cerrar el curso: " . $stmt->error;
    }

    // Cerrar conexiones
    $stmt->close();
    $conexion->close();
} else {
    echo "ID de curso no proporcionado.";
}
?>