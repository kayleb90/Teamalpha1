

<?php

session_start();

// Validación si no hay sesión activa
//if (!isset($_SESSION['usuario'])) {
 //   header("Location: ../LogIn/index.php");
  //  exit();
//}

// Validación de perfil: 1 = Usuario común, 0 = Admin
if ($_SESSION['TipoUsuario'] == 1) {
    include("../Header/Header.php");
    echo "
    <!DOCTYPE html>
<html lang='es>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Mantenimiento de Usuarios - Alpha Academy</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }
        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-modificar {
            background-color: #28a745;
            color: white;
        }
        .btn-modificar:hover {
            background-color: #218838;
        }
        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
        }
        footer a {
            color: #3498db;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class='container mt-4'>
    <h2 class='mb-4'>Mantenimiento de Cursos</h2>";
    echo "<h2 style='color:red; text-align:center; margin-top:50px;'>Su perfil no tiene acceso a esta sección.</h2>";
    exit(); 
}

include("../Header/Header.php");
include("../DB/DBConect.php");

$conexion = DBConectar();
$query = "SELECT c.idCurso, c.NombreCurso, c.FechaInicioCurso, c.DuracionCurso, c.CapacidadCurso, c.Disponibilidad, u.NombreUsuario
          FROM Cursos c
          INNER JOIN Usuarios u ON c.IdUsuario = u.idUsuario";
$resultado = $conexion->query($query);

if (!$resultado) {
    die("Error en la consulta: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mantenimiento de Cursos - Alpha Academy</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0; padding: 0; color: #2c3e50;
        }
        .container { width: 90%; margin: 0 auto; padding: 20px; }
        .table th, .table td { vertical-align: middle; }
        .btn-modificar { background-color: #28a745; color: white; }
        .btn-modificar:hover { background-color: #218838; }
        .btn-cerrar { background-color: #dc3545; color: white; }
        .btn-cerrar:hover { background-color: #c82333; }
        footer { background-color: #2c3e50; color: white; text-align: center; padding: 10px; }
        footer a { color: #3498db; text-decoration: none; }
        footer a:hover { text-decoration: underline; }
    </style>
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-4">Mantenimiento de Cursos</h2>
    <table class="table table-bordered table-hover bg-white">
        <thead class="table-primary">
            <tr>
                <th>Nombre del Curso</th>
                <th>Profesor</th>
                <th>Fecha de Inicio</th>
                <th>Duración (horas)</th>
                <th>Capacidad</th>
                <th>Cupos Disponibles</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($resultado->num_rows > 0) {
                while ($curso = $resultado->fetch_assoc()) {
                    $fechaInicio = date('d/m/Y', strtotime($curso['FechaInicioCurso']));
                    $enlace_modificar = "../Modificar_Cursos/index.php?" . 
                        "course_id=" . urlencode($curso['idCurso']) . "&" .
                        "course_name=" . urlencode($curso['NombreCurso']) . "&" .
                        "description=" . urlencode($curso['NombreCurso']) . "&" .
                        "start_date=" . urlencode($curso['FechaInicioCurso']) . "&" .
                        "end_date=" . urlencode(date('Y-m-d', strtotime($curso['FechaInicioCurso'] . ' + ' . $curso['DuracionCurso'] . ' days'))) . "&" .
                        "cupos_disponibles=" . urlencode($curso['Disponibilidad']) . "&" .
                        "instructor=" . urlencode($curso['NombreUsuario']);

                    echo "<tr>
                        <td>" . htmlspecialchars($curso['NombreCurso']) . "</td>
                        <td>" . htmlspecialchars($curso['NombreUsuario']) . "</td>
                        <td>" . $fechaInicio . "</td>
                        <td>" . htmlspecialchars($curso['DuracionCurso']) . "</td>
                        <td>" . htmlspecialchars($curso['CapacidadCurso']) . "</td>
                        <td>" . htmlspecialchars($curso['Disponibilidad']) . "</td>
                        <td>
                            <a href='$enlace_modificar' class='btn btn-warning btn-sm'>Modificar</a>";

                    if ($curso['Disponibilidad'] > 0) {
                        echo " <a href='cerrar_curso.php?id=" . $curso['idCurso'] . "' class='btn btn-sm btn-cerrar' onclick='return confirm(\"¿Estás seguro de que deseas cerrar este curso?\");'>Cerrar Curso</a>";
                    } else {
                        echo " <button class='btn btn-sm btn-secondary' disabled>Curso Cerrado</button>";
                    }

                    echo "</td></tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No se encontraron cursos.</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <button type="button" class="btn btn-primary" onclick="window.location.href='../Modificar_Cursos/index.php';">Agregar Nuevo Curso</button>
</div>

<footer>
    <p>&copy; 2025 Alpha Academy. Todos los derechos reservados.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conexion->close(); ?>