<?php
session_start(); // Asegúrate de iniciar la sesión aquí.

if (isset($_SESSION['idUsuario'])) {
    header("Location: /index.php");
    exit;
}

include('/xampp/htdocs/DB/DBConect.php'); // Ruta correcta a tu conexión

// Variables para mensajes de error
$errors = [];
$email = $password = '';

// Procesar el formulario cuando se envía
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email)) {
        $errors['email'] = 'El correo electrónico es requerido';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Por favor ingresa un correo electrónico válido';
    }

    if (empty($password)) {
        $errors['password'] = 'La contraseña es requerida';
    }

    if (empty($errors)) {
        try {
            $conexion = DBConectar();
            $stmt = $conexion->prepare("CALL SP_ValidarCredenciales(?, ?)");

            $hashedPassword = hash('sha256', $password);
            $stmt->bind_param("ss", $email, $hashedPassword);
            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($resultado && $fila = $resultado->fetch_assoc()) {
                if ($fila['credenciales_validas']) {
                    $_SESSION['idUsuario'] = $fila['idUsuario'];
                    $_SESSION['NombreUsuario'] = $fila['NombreUsuario'];
                    $_SESSION['CorreoUsuario'] = $fila['CorreoUsuario'];
                    $_SESSION['TipoUsuario'] = $fila['TipoUsuario'];

                    header('Location: /index.php');
                    exit;
                } else {
                    $errors['general'] = 'Correo o contraseña incorrectos';
                }
            } else {
                $errors['general'] = 'Error al verificar credenciales';
            }

            $stmt->close();
            $conexion->close();
        } catch (Exception $e) {
            $errors['general'] = 'Error: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión - Alpha Academy</title>
    <style>
        /* Estilos simplificados (igual que antes) */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h1, h2 {
            text-align: center;
            color: #3498db;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #ddd;
        }

        .error {
            color: #e74c3c;
            font-size: 14px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 4px;
        }

        .signup-link {
            text-align: center;
            margin-top: 20px;
        }

        .signup-link a {
            color: #3498db;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Alpha Academy</h1>
    <h2>Iniciar Sesión</h2>

    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="index.php" method="POST">
        <div class="form-group">
            <label for="email">Correo Electrónico</label>
            <input type="email" name="email" id="email" value="<?= htmlspecialchars($email) ?>" required>
        </div>
        <div class="form-group">
            <label for="password">Contraseña</label>
            <input type="password" name="password" id="password" required>
        </div>
        <button type="submit">Iniciar sesión</button>
    </form>

    <div class="signup-link">
        ¿No tienes una cuenta? <a href="../Register">Regístrate</a>
    </div>
</div>
</body>
</html>