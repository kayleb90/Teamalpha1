<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Centro Educativo - Cursos en Línea</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #2c3e50;
        }

        header {
            background-color: #3498db;
            color: white;
            text-align: center;
            padding: 20px;
        }

        header h1 {
            margin: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }

        .section-title {
            font-size: 24px;
            color: #3498db;
            margin-bottom: 15px;
        }

        .section {
            margin-bottom: 30px;
        }

        .cta-button {
            background-color: #3498db;
            color: white;
            padding: 12px 25px;
            font-size: 18px;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .cta-button:hover {
            background-color: #2980b9;
        }

        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
        }

        footer a {
            color: #3498db;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<?php
      include "../Header/Header.php";
    ?>

<div class="container">
    <h2 class="section-title">Agregar un Nuevo Curso</h2>
    <p>Utiliza este formulario para agregar un nuevo curso a nuestra lista de cursos disponibles. Asegúrate de proporcionar toda la información necesaria.</p>

    <form action="agregar_curso.php" method="POST">
        <!-- Nombre del curso -->
        <div class="mb-3">
            <label for="courseName" class="form-label">Nombre del curso</label>
            <input type="text" class="form-control" id="courseName" name="courseName" required>
        </div>

        <!-- Descripción del curso -->
        <div class="mb-3">
            <label for="courseDescription" class="form-label">Descripción del curso</label>
            <textarea class="form-control" id="courseDescription" name="courseDescription" rows="4" required></textarea>
        </div>

        <!-- Duración del curso -->
        <div class="mb-3">
            <label for="courseDuration" class="form-label">Duración del curso (en horas)</label>
            <input type="number" class="form-control" id="courseDuration" name="courseDuration" min="1" required>
        </div>

        <!-- Precio del curso -->
        <div class="mb-3">
            <label for="coursePrice" class="form-label">Precio del curso (en USD)</label>
            <input type="number" class="form-control" id="coursePrice" name="coursePrice" min="0" step="0.01" required>
        </div>

        <!-- Categoría del curso -->
        <div class="mb-3">
            <label for="courseCategory" class="form-label">Categoría del curso</label>
            <select class="form-select" id="courseCategory" name="courseCategory" required>
                <option value="" disabled selected>Selecciona una categoría</option>
                <option value="Desarrollo Web">Desarrollo Web</option>
                <option value="Marketing Digital">Marketing Digital</option>
                <option value="Programación en Python">Programación en Python</option>
                <option value="Gestión Empresarial">Gestión Empresarial</option>
                <option value="Psicología y Bienestar">Psicología y Bienestar</option>
                <option value="Diseño Gráfico">Diseño Gráfico</option>
            </select>
        </div>

        <!-- Fecha de inicio del curso -->
        <div class="mb-3">
            <label for="courseStartDate" class="form-label">Fecha de inicio del curso</label>
            <input type="date" class="form-control" id="courseStartDate" name="courseStartDate" required>
        </div>

        <!-- Estado del curso -->
        <div class="mb-3">
            <label for="courseStatus" class="form-label">Estado del curso</label>
            <select class="form-select" id="courseStatus" name="courseStatus" required>
                <option value="" disabled selected>Selecciona el estado del curso</option>
                <option value="Disponible">Disponible</option>
                <option value="No Disponible">No Disponible</option>
            </select>
        </div>

        <!-- Cupo máximo del curso -->
        <div class="mb-3">
            <label for="courseMaxQuota" class="form-label">Cupo máximo del curso</label>
            <input type="number" class="form-control" id="courseMaxQuota" name="courseMaxQuota" min="1" required>
        </div>

        <!-- Botón de enviar -->
        <button type="submit" class="btn btn-success">Agregar Curso</button>
    </form>
</div>



    <footer class="footer-dark">
        <p>&copy; 2025 Centro Educativo XYZ. Todos los derechos reservados.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
